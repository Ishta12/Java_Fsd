package com.coforge.training.mockitodemo;

public interface IDemo {
	
	String S="Hello World";  //by default constan
	
	String greet();   //by default Abstract

}
