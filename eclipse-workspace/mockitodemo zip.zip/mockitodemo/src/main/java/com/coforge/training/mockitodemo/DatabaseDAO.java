package com.coforge.training.mockitodemo;

public class DatabaseDAO {

	public void save(String fileName) {
		System.out.println("Saved in network Location");
	}
}
